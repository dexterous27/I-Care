function sendMessage() {
    const userInput = document.getElementById('userInput').value;
    const chatWindow = document.getElementById('chat');
  
    // Create a new chat bubble for the user's message
    const userBubble = document.createElement('div');
    userBubble.className = 'user-bubble';
    userBubble.innerText = userInput;
  
    // Append the chat bubble to the chat window
    chatWindow.appendChild(userBubble);
  
    fetch('http://localhost:5005/webhooks/rest/webhook', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message: userInput }),
    })
      .then((response) => response.json())
      .then((data) => {
        const botReply = data[0].text;
  
        // Create a new chat bubble for the bot's reply
        const botBubble = document.createElement('div');
        botBubble.className = 'bot-bubble';
        botBubble.innerText = botReply;
  
        // Append the chat bubble to the chat window
        chatWindow.appendChild(botBubble);
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  
    // Clear the input field after sending the message
    document.getElementById('userInput').value = '';
  }
  